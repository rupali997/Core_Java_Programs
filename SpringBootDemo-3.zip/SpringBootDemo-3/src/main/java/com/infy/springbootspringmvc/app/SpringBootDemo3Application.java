package com.infy.springbootspringmvc.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemo3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemo3Application.class, args);
	}

}
