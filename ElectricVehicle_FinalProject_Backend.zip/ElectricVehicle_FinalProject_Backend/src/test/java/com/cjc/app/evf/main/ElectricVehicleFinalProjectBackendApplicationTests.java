package com.cjc.app.evf.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectricVehicleFinalProjectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
