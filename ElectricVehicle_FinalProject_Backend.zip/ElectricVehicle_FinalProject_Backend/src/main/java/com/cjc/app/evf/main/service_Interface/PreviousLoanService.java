package com.cjc.app.evf.main.service_Interface;

public interface PreviousLoanService {

}
