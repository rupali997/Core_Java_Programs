package com.cjc.app.evf.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricVehicleFinalProjectBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricVehicleFinalProjectBackendApplication.class, args);
	}

}
