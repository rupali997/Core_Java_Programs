package com.cjc.app.evf.main.service_Implementation;

import org.springframework.stereotype.Service;

import com.cjc.app.evf.main.service_Interface.PreviousLoanService;

@Service
public class PreviousLoanImpl implements PreviousLoanService {

}
