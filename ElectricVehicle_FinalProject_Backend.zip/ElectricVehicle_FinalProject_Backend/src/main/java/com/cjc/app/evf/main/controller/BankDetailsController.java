package com.cjc.app.evf.main.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class BankDetailsController {

	
	
}
