package com.cjc.app.evf.main.service_Interface;

import com.cjc.app.evf.main.model.DocumentDetails;

public interface EvfServiceI {

	void saveDoucments(DocumentDetails value);

}
