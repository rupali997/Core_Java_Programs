package com.infy.springbootspringmvccrud.app.dao_Implementation;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infy.springbootspringmvccrud.app.dao_Interface.UserDao;
import com.infy.springbootspringmvccrud.app.model.Login;
import com.infy.springbootspringmvccrud.app.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	SessionFactory sf;

	@Override
	public int saveUser(User u) {
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(u);
		tx.commit();
		session.close();
		return u.getUid();
	}

	@Override
	public int deleteUser(int uid) {

		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("delete User where uid=:id");
		query.setParameter("id", uid);
		int x = query.executeUpdate();
		tx.commit();
		return x;
	}

	@Override
	public List<User> getAllUsers(int i) {
		Session session = sf.openSession();
		return session.createQuery("from User where rol.rid=" + i + "").getResultList();
	}

	@Override
	public User loginCheck(User u) {
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();

		User newuser = null;

		try {

			Query query = session.createQuery("from User where login.username='" + u.getLogin().getUsername()
					+ "' and login.password='" + u.getLogin().getPassword() + "'");
			User u1 = (User) query.getSingleResult();
			newuser = u1;
		} catch (Exception e) {
			System.out.println("No such data found!!");
			return newuser;
		}

		return newuser;

	}

}
