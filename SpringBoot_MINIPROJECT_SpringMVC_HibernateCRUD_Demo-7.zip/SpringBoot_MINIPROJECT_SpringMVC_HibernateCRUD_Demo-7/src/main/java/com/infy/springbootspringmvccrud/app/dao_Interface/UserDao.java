package com.infy.springbootspringmvccrud.app.dao_Interface;

import java.util.List;

import com.infy.springbootspringmvccrud.app.model.User;

public interface UserDao {

	int saveUser(User u);

	int deleteUser(int uid);

	List<User> getAllUsers(int i);

	

	User loginCheck(User u);

	

	
}
