package com.infy.springbootmvcjparestapistatuscodecrud.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpStatusCode1Application {

	public static void main(String[] args) {
		SpringApplication.run(HttpStatusCode1Application.class, args);
	}

}
