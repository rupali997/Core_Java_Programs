package com.infy.springbootspringmvcjpacrud.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSpringJpaCrud5JpqLqueriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSpringJpaCrud5JpqLqueriesApplication.class, args);
	}

}
