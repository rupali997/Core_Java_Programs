package com.infy.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsUCPConsumerDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
