package com.infy.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsUCPUiPageDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsUCPUiPageDbApplication.class, args);
	}

}
