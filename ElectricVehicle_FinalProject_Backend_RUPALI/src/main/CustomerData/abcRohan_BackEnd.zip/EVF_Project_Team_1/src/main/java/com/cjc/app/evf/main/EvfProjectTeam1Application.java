package com.cjc.app.evf.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvfProjectTeam1Application {

	public static void main(String[] args) {
		SpringApplication.run(EvfProjectTeam1Application.class, args);
	}

}
