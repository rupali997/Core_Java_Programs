package com.cjc.app.evf.main.service;

import com.cjc.app.evf.main.model.Sanction;

public interface SanServiceI {

	Sanction saveSanctionDetails(Sanction sanc);

	Sanction getAllDetails(int sid);

	

}
