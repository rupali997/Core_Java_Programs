package com.cjc.app.evf.main.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.app.evf.main.model.Sanction;
import com.cjc.app.evf.main.repository.SanRepository;
import com.cjc.app.evf.main.service.SanServiceI;

@Service
public class SanServiceImpl implements SanServiceI{
	
	@Autowired
	SanRepository sr;

	@Override
	public Sanction saveSanctionDetails(Sanction sanc) {
		
		return sr.save(sanc);
	}

	@Override
	public Sanction getAllDetails(int sid) {
		
		return sr.findById(sid).get();
	}



}
