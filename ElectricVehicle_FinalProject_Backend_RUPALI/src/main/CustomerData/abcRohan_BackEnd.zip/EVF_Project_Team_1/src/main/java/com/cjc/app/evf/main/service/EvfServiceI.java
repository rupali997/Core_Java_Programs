package com.cjc.app.evf.main.service;

import com.cjc.app.evf.main.model.Documents;

public interface EvfServiceI {

	void saveDoucments(Documents value);

}
