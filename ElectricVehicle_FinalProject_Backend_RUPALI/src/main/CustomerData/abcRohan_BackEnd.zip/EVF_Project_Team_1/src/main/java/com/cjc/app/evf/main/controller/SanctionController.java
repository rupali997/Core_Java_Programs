package com.cjc.app.evf.main.controller;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.app.evf.main.model.Sanction;
import com.cjc.app.evf.main.service.SanServiceI;

@RestController
@RequestMapping("/sanction")
public class SanctionController {
	
	@Autowired
	SanServiceI ss;
	
	@PostMapping("/post")
	public Sanction SanctionDetails(@RequestBody Sanction sanc) {
		
		double annualInterestRate=sanc.getRateOfInterest();
		int noOfYear=sanc.getLoanTenure();
		double loanAmount=sanc.getLoanAmtSanction();
		double MonthlyInterestRate=annualInterestRate/1200;
		double monthlyPayment=loanAmount*MonthlyInterestRate/(1-1/Math.pow(1+MonthlyInterestRate,noOfYear*12));
		double totalPayment=monthlyPayment*noOfYear*12;
		sanc.setMonthlyEMI(monthlyPayment);
		sanc.setTotalAmtPayble(totalPayment);
		sanc.setModeOfPayment("Cash");
		sanc.setStatus("active");
		sanc.setTermsAndConditions("true");
		
		
		System.out.println(monthlyPayment + " Rs.");
		System.out.println(totalPayment + " Rs.");
		Sanction s=ss.saveSanctionDetails(sanc);
		return s;
		
	}
	
	@GetMapping("/get/{sid}")
	public Sanction getSanctionDetailsByid(@PathVariable int sid) {
		
		
		Sanction s = ss.getAllDetails(sid);
		return s;
		
	}
	
	@DeleteMapping("del/{sid}")
	public Sanction deleteSanctionCertificate(@PathVariable int sid) {
		Sanction s = ss.getAllDetails(sid);
		s.setStatus("disabled");
		Sanction sn = ss.saveSanctionDetails(s);
		return sn;
	}
	
	@PutMapping("/upd")
	public Sanction updateSanction(@RequestBody Sanction s) {
		
		System.out.println(s.toString());
		Sanction sanUpd = ss.saveSanctionDetails(s);
		
		return sanUpd;
	}
	
	
	
	

	
	
	

	

}
